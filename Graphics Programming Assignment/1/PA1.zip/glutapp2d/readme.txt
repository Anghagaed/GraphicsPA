GLUTAPP2D
---------

This is a demo project to start implementing OpenGL applications
using freeglut and glew. 

Linux:
 - There is a makefile but it has not been tested for a long time
 - The makefile will/should compile all .cpp files in the folder
 - Edit the makefile to change the name of the executable

Windows:
 - Use the visual studio solution in the visualcXX folder
 - Make sure visual studio (Express or Community) is installed
 - To open the project just double click the .sln file

Note:
 - the provided freeglut library is only used in Windows; 
   in Linux the compiler will seek for the header files and 
   libraries in the usual development folders


